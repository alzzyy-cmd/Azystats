package com.azy.azyistatik;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * "/stats <oyuncu>" ekranında açılan GUI'yi oluşturur.
 * Tamamen bilgi amaçlıdır, hiçbir item alınamaz/tıklanamaz.
 */
public class StatsGUI {

    private final AzyIstatik plugin;

    public StatsGUI(AzyIstatik plugin) {
        this.plugin = plugin;
    }

    public Inventory build(OfflinePlayer target) {
        String titleTemplate = plugin.getConfig().getString("stats.gui-title", "&a&l%player% STATS");
        String title = ChatColor.translateAlternateColorCodes('&',
                titleTemplate.replace("%player%", target.getName() == null ? "Bilinmeyen" : target.getName()));

        StatsInventoryHolder holder = new StatsInventoryHolder();
        Inventory inv = org.bukkit.Bukkit.createInventory(holder, 36, title);
        holder.setInventory(inv);

        // Üst ve alt satırları cam panelle çerçeveliyoruz (görseldeki gibi boş çerçeve)
        ItemStack border = createItem(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, border);
            inv.setItem(27 + i, border);
        }
        inv.setItem(9, border);
        inv.setItem(17, border);
        inv.setItem(18, border);
        inv.setItem(26, border);

        String fallback = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("stats.placeholder-not-found-text", "&cPlaceholderAPI yok"));

        String balance = PlaceholderHook.resolve(target, plugin.getConfig().getString("stats.balance-placeholder"), fallback);
        String shards = PlaceholderHook.resolve(target, plugin.getConfig().getString("stats.shards-placeholder"), fallback);
        String earned = PlaceholderHook.resolve(target, plugin.getConfig().getString("stats.earned-placeholder"), fallback);
        String lost = PlaceholderHook.resolve(target, plugin.getConfig().getString("stats.lost-placeholder"), fallback);
        String playtime = PlaceholderHook.resolve(target, plugin.getConfig().getString("stats.playtime-placeholder"), fallback);

        int totalKills = StatsCollector.getTotalKills(target);
        int mobKills = StatsCollector.getMobKills(target);
        int blocksMined = StatsCollector.getBlocksMined(target);
        int blocksPlaced = StatsCollector.getBlocksPlaced(target);

        // 1. satır (slot 10-15): Bakiye, Shards, Öldürme, Kırılan Blok, Playtime, Koyulan Blok
        inv.setItem(10, createItem(Material.EMERALD, "&a&lBakiye",
                list("&7Mevcut para: &f" + balance)));

        inv.setItem(11, createItem(Material.AMETHYST_SHARD, "&d&lShards",
                list("&7Shards değeri: &f" + shards)));

        inv.setItem(12, createItem(Material.DIAMOND_SWORD, "&b&lÖldürme",
                list("&7Toplam öldürme: &f" + StatsCollector.format(totalKills))));

        inv.setItem(13, createItem(Material.COBBLESTONE, "&7&lKırılan Blok",
                list("&7Toplam kırılan blok: &f" + StatsCollector.format(blocksMined))));

        inv.setItem(14, createItem(Material.CLOCK, "&e&lPlaytime",
                list("&7Oynama süresi: &f" + playtime)));

        inv.setItem(15, createItem(Material.STONE, "&f&lKoyulan Blok",
                list("&7Toplam koyulan blok: &f" + StatsCollector.format(blocksPlaced))));

        // 2. satır (slot 19-21): Öldürülen Mob, Kazanılan Para, Kaybedilen Para
        inv.setItem(19, createSkull(target, "&2&lÖldürülen Mob",
                list("&7Öldürülen yaratık sayısı: &f" + StatsCollector.format(mobKills))));

        inv.setItem(20, createItem(Material.GOLD_NUGGET, "&6&lKazanılan Para",
                list("&7Toplam kazanılan: &f" + earned)));

        inv.setItem(21, createItem(Material.IRON_NUGGET, "&c&lKaybedilen Para",
                list("&7Toplam kaybedilen: &f" + lost)));

        // Alt bilgi: plugin geliştirici notu
        inv.setItem(31, createItem(Material.NETHER_STAR, "&b&lAzyIstatik",
                list("&7Bu istatistik ekranı", "&b&lazy &7(&balzzyy&7) &7tarafından", "&7geliştirilmiştir.")));

        return inv;
    }

    private List<String> list(String... lines) {
        List<String> result = new ArrayList<>();
        for (String line : lines) {
            result.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        return result;
    }

    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            if (lore != null) {
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createSkull(OfflinePlayer owner, String name, List<String> lore) {
        // Görsel olarak zombi kafası kullanıyoruz (öldürülen mob istatistiği için)
        ItemStack item = new ItemStack(Material.ZOMBIE_HEAD);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            if (lore != null) {
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}
