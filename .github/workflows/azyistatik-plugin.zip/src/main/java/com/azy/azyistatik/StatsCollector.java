package com.azy.azyistatik;

import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.entity.EntityType;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Bukkit'in kendi Statistic sistemi üzerinden oyuncuya ait
 * kill, blok kırma ve blok koyma verilerini hesaplar.
 * Hem online hem offline oyuncularda çalışır.
 */
public class StatsCollector {

    private static final Locale TR = new Locale("tr", "TR");

    /** Oyuncu + mob toplam öldürme sayısı. */
    public static int getTotalKills(OfflinePlayer player) {
        int kills = 0;
        try {
            kills += player.getStatistic(Statistic.PLAYER_KILLS);
        } catch (Throwable ignored) {
        }
        for (EntityType type : EntityType.values()) {
            if (!type.isAlive()) continue;
            try {
                kills += player.getStatistic(Statistic.KILL_ENTITY, type);
            } catch (Throwable ignored) {
                // Bazı EntityType değerleri istatistik desteklemez, atla
            }
        }
        return kills;
    }

    /** Sadece mob (yaratık) öldürme sayısı - oyuncu kill'leri hariç. */
    public static int getMobKills(OfflinePlayer player) {
        int kills = 0;
        for (EntityType type : EntityType.values()) {
            if (!type.isAlive() || type == EntityType.PLAYER) continue;
            try {
                kills += player.getStatistic(Statistic.KILL_ENTITY, type);
            } catch (Throwable ignored) {
                // desteklenmeyen tip
            }
        }
        return kills;
    }

    /** Kırılan (madencilik yapılan) blok sayısı toplamı. */
    public static int getBlocksMined(OfflinePlayer player) {
        int total = 0;
        for (Material material : Material.values()) {
            if (!material.isBlock() || material.isLegacy()) continue;
            try {
                total += player.getStatistic(Statistic.MINE_BLOCK, material);
            } catch (Throwable ignored) {
                // istatistik desteklemeyen materyal
            }
        }
        return total;
    }

    /** Koyulan (yerleştirilen) blok sayısı toplamı. */
    public static int getBlocksPlaced(OfflinePlayer player) {
        int total = 0;
        for (Material material : Material.values()) {
            if (!material.isBlock() || !material.isItem() || material.isLegacy()) continue;
            try {
                total += player.getStatistic(Statistic.USE_ITEM, material);
            } catch (Throwable ignored) {
                // istatistik desteklemeyen materyal
            }
        }
        return total;
    }

    public static String format(int number) {
        return NumberFormat.getInstance(TR).format(number);
    }
}
