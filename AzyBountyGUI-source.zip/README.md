# AzyBountyGUI

DonutBounty verileri için hazır bir GUI arayüzü. DonutDatabase eklentisinin
`storage.db` (SQLite) dosyasındaki `bounties` tablosunu **doğrudan** okur/yazar;
DonutBounty veya DonutDatabase'e API bağımlılığı yoktur, bu yüzden her iki
eklentiyle de sorunsuz birlikte çalışır ve tamamen offline oyuncu desteklidir.

## Özellikler

- `/bounty` komutu ile 6 satırlık (54 slot) GUI açılır
- Oyuncu skin kafaları (offline oyuncular için de doğru görünür)
- Sıralama: **#1 altın, #2 gümüş, #3 bronz/kırmızı, geri kalanlar gri**
- Alt satırda geri/ileri sayfa okları + ortada **Anvil "Yenile"** tuşu
  (basınca listeyi anlık SQLite'tan tekrar çeker, yeni eklenen bounty'ler
  hemen görünür)
- Üst satırda sol-orta bölgede **iskelet kafası** ("Bounty Sistemi nasıl
  çalışır" bilgi/yardım kutusu — oyuncuya bounty nasıl eklenir vs. anlatır)
- Üst satırda sağ-orta bölgede **tabela (Oak Sign)** — tıklayınca gerçek bir
  tabela düzenleme ekranı açılır, oyuncu ismi yazılınca o oyuncunun bounty
  bilgisi chat'te gösterilir
- `/bounty add <oyuncu> <miktar>` — bounty ekler (varsa üzerine ekler)
- `/bounty remove <oyuncu>` — bounty kaldırır
- `/bounty reload` — config.yml'i yeniden yükler

## Kurulum

1. `AzyBountyGUI.jar` dosyasını sunucunun `plugins/` klasörüne at.
2. Sunucuyu başlat/yeniden başlat.
3. `plugins/AzyBountyGUI/config.yml` içindeki `database.path` değerinin
   DonutDatabase'in gerçek `storage.db` konumuyla eşleştiğinden emin ol
   (varsayılan: `plugins/DonutDatabase/storage.db`).
4. `/bounty` yaz ve dene.

## İzinler

| İzin                     | Varsayılan | Açıklama                          |
|--------------------------|------------|------------------------------------|
| `azybountygui.use`       | herkes     | `/bounty` GUI'sini açabilir       |
| `azybountygui.admin`     | op         | bounty ekleme/silme/reload         |

## Kaynak koddan derleme

Projeyi mobil cihazdan derlemen gerekmiyor — bu repo'yu GitHub'a
yüklediğinde `.github/workflows/build.yml` otomatik olarak Maven ile
derler ve "Actions" sekmesinde `AzyBountyGUI.jar` dosyasını **Artifacts**
olarak indirebilirsin (AzyCombat'taki CI akışıyla aynı mantık).

Kendi bilgisayarında derlemek istersen:

```bash
mvn clean package
```

Çıktı: `target/AzyBountyGUI.jar`

## Notlar / Bilinmesi gerekenler

- Tabela sorgu sistemi, oyuncunun tam üstünde (dünyanın build-height
  sınırının en tepesinde, hiç kimsenin görmediği bir noktada) geçici bir
  tabela bloğu yerleştirip Paper'ın gerçek "sign edit" arayüzünü açar.
  İsim girildiğinde tabela otomatik kaldırılır; 30 saniye içinde
  kapatılmazsa da otomatik temizlenir. Hiçbir oyuncu binası/arazisi
  etkilenmez.
- `database.path` config'te oynanabilir; eğer `plugins/...` ile başlamıyorsa
  tam/absolute yol olarak kullanılır.
- Bounty ekleme mantığı **upsert**'tür: aynı oyuncuya tekrar bounty
  eklenirse mevcut miktarın üzerine eklenir (DonutBounty'nin standart
  davranışına benzer).
