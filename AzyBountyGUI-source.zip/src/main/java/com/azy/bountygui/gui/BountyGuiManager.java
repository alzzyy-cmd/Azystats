package com.azy.bountygui.gui;

import com.azy.bountygui.AzyBountyGUI;
import com.azy.bountygui.db.BountyEntry;
import com.azy.bountygui.util.ItemBuilder;
import com.azy.bountygui.util.SkullUtil;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class BountyGuiManager {

    private final AzyBountyGUI plugin;

    public BountyGuiManager(AzyBountyGUI plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, int page) {
        FileConfiguration cfg = plugin.getConfig();
        int rows = cfg.getInt("gui.rows", 6);
        int size = rows * 9;
        String title = ItemBuilder.color(cfg.getString("gui.title", "&8&lBounty Sistemi"));

        BountyGuiHolder holder = new BountyGuiHolder(page);
        Inventory inv = plugin.getServer().createInventory(holder, size, title);

        List<BountyEntry> all = plugin.getRepository().getAllSortedDesc();

        int infoSlot = cfg.getInt("gui.info_button_slot", 3);
        int signSlot = 5;
        int bottomRowStart = (rows - 1) * 9;

        // Üst satırdaki iskelet kafası ve tabela slotları hariç, kalan tüm
        // slotlar (son satır dahil değil) oyuncu bounty kafaları için kullanılır.
        List<Integer> availableSlots = new ArrayList<>();
        for (int i = 0; i < bottomRowStart; i++) {
            if (i == infoSlot || i == signSlot) continue;
            availableSlots.add(i);
        }

        int pageSize = Math.min(cfg.getInt("gui.page_size", 45), availableSlots.size());
        int maxPage = all.isEmpty() ? 0 : Math.max(0, (all.size() - 1) / pageSize);
        if (page > maxPage) page = maxPage;
        if (page < 0) page = 0;
        holder.setPage(page);

        int start = page * pageSize;
        int end = Math.min(start + pageSize, all.size());

        for (int i = start; i < end; i++) {
            BountyEntry entry = all.get(i);
            int rank = i + 1;
            int slot = availableSlots.get(i - start);
            inv.setItem(slot, buildEntryItem(entry, rank));
        }

        // Alt bar (son satır): geri | ... | yenile(anvil, ortada) ... | ileri
        // Üst satırdaki info kafası ve tabela burada da (yeniden) yerleştirilir.
        fillBottomBar(inv, holder, all.size(), pageSize);

        player.openInventory(inv);
    }

    private void fillBottomBar(Inventory inv, BountyGuiHolder holder, int totalEntries, int pageSize) {
        FileConfiguration cfg = plugin.getConfig();
        int rows = cfg.getInt("gui.rows", 6);
        int bottomRowStart = (rows - 1) * 9;

        // Dolgu camı - alt satırın kullanılmayan kısımlarını nötr bırak
        ItemStack filler = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = bottomRowStart; i < bottomRowStart + 9; i++) {
            inv.setItem(i, filler);
        }

        int prevSlot = cfg.getInt("gui.prev_button_slot", 48);
        int nextSlot = cfg.getInt("gui.next_button_slot", 50);
        int refreshSlot = cfg.getInt("gui.refresh_button_slot", 49);

        int maxPage = Math.max(0, (totalEntries - 1) / pageSize);

        if (holder.getPage() > 0) {
            inv.setItem(prevSlot, new ItemBuilder(Material.ARROW)
                    .name(cfg.getString("prev_item.name", "&a&l« Önceki Sayfa"))
                    .lore(List.of("&7Sayfa " + holder.getPage() + " / " + (maxPage + 1)))
                    .build());
        }

        if (holder.getPage() < maxPage) {
            inv.setItem(nextSlot, new ItemBuilder(Material.ARROW)
                    .name(cfg.getString("next_item.name", "&a&lSonraki Sayfa »"))
                    .lore(List.of("&7Sayfa " + (holder.getPage() + 2) + " / " + (maxPage + 1)))
                    .build());
        }

        // Anvil yenileme tuşu - tam ortada
        inv.setItem(refreshSlot, new ItemBuilder(Material.ANVIL)
                .name(cfg.getString("refresh_item.name", "&b&lYenile"))
                .lore(cfg.getStringList("refresh_item.lore"))
                .build());

        // İskelet kafası - info/yardım butonu, üst orta satırın SOL-orta kısmı (slot 3)
        List<String> infoLore = cfg.getStringList("info_item.lore");
        inv.setItem(cfg.getInt("gui.info_button_slot", 3), new ItemBuilder(Material.SKELETON_SKULL)
                .name(cfg.getString("info_item.name", "&eBounty Sistemi &7- Yardım"))
                .lore(infoLore)
                .build());

        // Tabela - üst orta satırın SAĞ-orta kısmı (slot 5), bounty sorgulama için
        inv.setItem(5, new ItemBuilder(Material.OAK_SIGN)
                .name("&e&lBounty Sorgula")
                .lore(List.of(
                        "&7Bir oyuncunun bounty'sini",
                        "&7öğrenmek için tıkla ve",
                        "&7ismini tabelaya yaz."
                ))
                .build());
    }

    private ItemStack buildEntryItem(BountyEntry entry, int rank) {
        FileConfiguration cfg = plugin.getConfig();

        ItemStack head = SkullUtil.createPlayerHead(entry.getPlayerName());
        SkullMeta meta = (SkullMeta) head.getItemMeta();

        String colorCode;
        switch (rank) {
            case 1:
                colorCode = cfg.getString("gui.medal_colors.first", "&6");
                break;
            case 2:
                colorCode = cfg.getString("gui.medal_colors.second", "&7");
                break;
            case 3:
                colorCode = cfg.getString("gui.medal_colors.third", "&c");
                break;
            default:
                colorCode = cfg.getString("gui.medal_colors.default", "&8");
                break;
        }

        String displayName = ItemBuilder.color(colorCode + "#" + rank + " &f" + entry.getPlayerName());
        meta.setDisplayName(displayName);

        List<String> lore = new ArrayList<>();
        for (String line : cfg.getStringList("format.entry_lore")) {
            String formatted = line
                    .replace("{amount}", formatAmount(entry.getAmount()))
                    .replace("{color}", colorCode)
                    .replace("{rank}", String.valueOf(rank));
            lore.add(ChatColor.translateAlternateColorCodes('&', formatted));
        }
        meta.setLore(lore);

        head.setItemMeta(meta);
        return head;
    }

    private String formatAmount(double amount) {
        if (amount == Math.floor(amount)) {
            return String.format("%,.0f", amount);
        }
        return String.format("%,.2f", amount);
    }
}
