package com.azy.bountygui.gui;

import com.azy.bountygui.AzyBountyGUI;
import com.azy.bountygui.sign.BountySignQuery;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class BountyGuiListener implements Listener {

    private final AzyBountyGUI plugin;
    private final BountyGuiManager manager;

    public BountyGuiListener(AzyBountyGUI plugin) {
        this.plugin = plugin;
        this.manager = new BountyGuiManager(plugin);
    }

    public BountyGuiManager getManager() {
        return manager;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof BountyGuiHolder holder)) {
            return;
        }

        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) {
            return;
        }

        FileConfiguration cfg = plugin.getConfig();
        int slot = event.getRawSlot();

        if (slot == cfg.getInt("gui.refresh_button_slot", 49) && clicked.getType() == Material.ANVIL) {
            manager.open(player, holder.getPage());
            player.sendMessage(plugin.color("&aBounty listesi yenilendi."));
            return;
        }

        if (slot == cfg.getInt("gui.prev_button_slot", 48) && clicked.getType() == Material.ARROW) {
            manager.open(player, holder.getPage() - 1);
            return;
        }

        if (slot == cfg.getInt("gui.next_button_slot", 50) && clicked.getType() == Material.ARROW) {
            manager.open(player, holder.getPage() + 1);
            return;
        }

        if (clicked.getType() == Material.OAK_SIGN) {
            player.closeInventory();
            BountySignQuery.startConversation(plugin, player);
            return;
        }

        if (clicked.getType() == Material.SKELETON_SKULL) {
            // info kafası - sadece bilgi amaçlı, işlem yok
            return;
        }

        // Oyuncu kafalarına tıklamanın şu an bir efekti yok (ileride "hedefe git" vs eklenebilir)
    }
}
