package com.azy.bountygui.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class BountyGuiHolder implements InventoryHolder {

    private int page;

    public BountyGuiHolder(int page) {
        this.page = page;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    @Override
    public Inventory getInventory() {
        // Bukkit API gereği override edilmesi zorunlu; gerçek envanter referansı
        // BountyGuiListener/BountyGuiManager tarafında tutulduğundan burada null döner.
        return null;
    }
}
