package com.azy.bountygui;

import com.azy.bountygui.commands.BountyCommand;
import com.azy.bountygui.db.BountyRepository;
import com.azy.bountygui.gui.BountyGuiListener;
import com.azy.bountygui.sign.BountySignListener;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public class AzyBountyGUI extends JavaPlugin {

    private static AzyBountyGUI instance;
    private BountyRepository repository;
    private BountyGuiListener guiListener;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        try {
            this.repository = new BountyRepository(this);
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Bounty veritabanına bağlanılamadı! Eklenti devre dışı bırakılıyor.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        BountyCommand bountyCommand = new BountyCommand(this);
        getCommand("bounty").setExecutor(bountyCommand);
        getCommand("bounty").setTabCompleter(bountyCommand);

        this.guiListener = new BountyGuiListener(this);
        getServer().getPluginManager().registerEvents(guiListener, this);
        getServer().getPluginManager().registerEvents(new BountySignListener(this), this);

        getLogger().info("AzyBountyGUI aktif edildi. (Alzzyy)");
    }

    @Override
    public void onDisable() {
        if (repository != null) {
            repository.close();
        }
    }

    public static AzyBountyGUI getInstance() {
        return instance;
    }

    public BountyRepository getRepository() {
        return repository;
    }

    public BountyGuiListener getGuiListener() {
        return guiListener;
    }

    public String color(String s) {
        return net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', s);
    }

    public String msg(String key) {
        String raw = getConfig().getString("messages." + key, "");
        return color(getConfig().getString("messages.prefix", "") + raw);
    }
}
