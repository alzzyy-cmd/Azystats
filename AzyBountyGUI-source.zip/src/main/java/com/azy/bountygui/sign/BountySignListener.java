package com.azy.bountygui.sign;

import com.azy.bountygui.AzyBountyGUI;
import com.azy.bountygui.db.BountyEntry;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

public class BountySignListener implements Listener {

    private final AzyBountyGUI plugin;

    public BountySignListener(AzyBountyGUI plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSignChange(SignChangeEvent event) {
        Location loc = event.getBlock().getLocation();
        String key = BountySignQuery.locKey(loc);

        if (!BountySignQuery.ACTIVE_QUERY_LOCATIONS.remove(key)) {
            return; // bu tabela bizim sorgu tabelamız değil
        }

        String playerName = event.line(1) != null
                ? PlainTextComponentSerializer.plainText().serialize(event.line(1))
                : "";

        var player = event.getPlayer();
        Block block = event.getBlock();

        // Bir tick sonra geçici tabelayı kaldır (event henüz tamamlanmadan bloğu değiştirmek sorun çıkarabilir)
        Bukkit.getScheduler().runTask(plugin, () -> {
            block.setType(Material.AIR);

            if (playerName == null || playerName.isBlank()) {
                player.sendMessage(plugin.color("&cBir isim girmedin, sorgu iptal edildi."));
                return;
            }

            BountyEntry entry = plugin.getRepository().findByName(playerName.trim());
            if (entry == null) {
                player.sendMessage(plugin.msg("bounty_not_found").replace("{player}", playerName.trim()));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            } else {
                String formatted = entry.getAmount() == Math.floor(entry.getAmount())
                        ? String.format("%,.0f", entry.getAmount())
                        : String.format("%,.2f", entry.getAmount());
                player.sendMessage(plugin.color("&8&m----------------------------"));
                player.sendMessage(plugin.color("&6Bounty Sorgu Sonucu"));
                player.sendMessage(plugin.color("&7Oyuncu: &f" + entry.getPlayerName()));
                player.sendMessage(plugin.color("&7Ödül: &a$" + formatted));
                player.sendMessage(plugin.color("&8&m----------------------------"));
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Oyuncu ayrılırsa açık kalan geçici tabelaları temizlemeye gerek yok,
        // 30 saniyelik otomatik temizleyici zaten devrede (BountySignQuery).
    }
}
