package com.azy.bountygui.sign;

import com.azy.bountygui.AzyBountyGUI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;

/**
 * Oyuncu GUI'deki tabelaya tıkladığında, oyuncunun ayaklarının hemen altında
 * geçici bir tabela bloğu yerleştirip Paper'ın gerçek "sign edit" arayüzünü
 * (Player#openSign) açar. Oyuncu ismi yazıp onayladığında SignChangeEvent
 * yakalanır, bounty veritabanında aranır ve sonuç chat'te gösterilir; ardından
 * geçici tabela kaldırılıp orijinal blok geri getirilir.
 */
public final class BountySignQuery {

    // Bu setteki tabela konumları "sorgu tabelası" olarak işaretlidir.
    public static final Set<String> ACTIVE_QUERY_LOCATIONS = new HashSet<>();

    private BountySignQuery() {
    }

    public static void startConversation(AzyBountyGUI plugin, Player player) {
        Location loc = findSafeSignLocation(player);
        Block block = loc.getBlock();
        Material original = block.getType();

        String key = locKey(loc);
        ACTIVE_QUERY_LOCATIONS.add(key);

        block.setType(Material.OAK_SIGN);

        if (!(block.getState() instanceof Sign sign)) {
            block.setType(original);
            ACTIVE_QUERY_LOCATIONS.remove(key);
            player.sendMessage(plugin.color("&cTabela açılamadı, tekrar dene."));
            return;
        }

        sign.getSide(Side.FRONT).line(0, Component.text("Oyuncu Adi:").color(NamedTextColor.DARK_BLUE));
        sign.update(true, false);

        // 2 tick sonra editörü aç (blok güncellemesinin client'a ulaşması için)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            player.openSign(sign, Side.FRONT);
            player.playSound(player.getLocation(), Sound.BLOCK_WOOD_PLACE, 0.6f, 1.2f);
        }, 2L);

        // Güvenlik: 30 saniye içinde kapatılmazsa geçici tabelayı temizle
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (ACTIVE_QUERY_LOCATIONS.remove(key)) {
                block.setType(original);
            }
        }, 600L);
    }

    private static Location findSafeSignLocation(Player player) {
        Location base = player.getLocation().clone();
        int topY = base.getWorld().getMaxHeight() - 1;
        base.setY(topY);
        return base.getBlock().getLocation();
    }

    public static String locKey(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }
}
