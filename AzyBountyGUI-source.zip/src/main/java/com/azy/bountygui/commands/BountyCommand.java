package com.azy.bountygui.commands;

import com.azy.bountygui.AzyBountyGUI;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class BountyCommand implements CommandExecutor, TabCompleter {

    private final AzyBountyGUI plugin;

    public BountyCommand(AzyBountyGUI plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(plugin.color("&cBu komut sadece oyuncular tarafından kullanılabilir."));
                return true;
            }
            if (!player.hasPermission("azybountygui.use")) {
                player.sendMessage(plugin.msg("no_permission"));
                return true;
            }
            openGui(player);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "add" -> handleAdd(sender, args);
            case "remove", "sil" -> handleRemove(sender, args);
            case "reload" -> {
                if (!sender.hasPermission("azybountygui.admin")) {
                    sender.sendMessage(plugin.msg("no_permission"));
                    return true;
                }
                plugin.reloadConfig();
                sender.sendMessage(plugin.color("&aConfig yeniden yüklendi."));
            }
            default -> {
                if (sender instanceof Player player && player.hasPermission("azybountygui.use")) {
                    openGui(player);
                } else {
                    sender.sendMessage(plugin.color("&cKullanım: /bounty | /bounty add <oyuncu> <miktar> | /bounty remove <oyuncu>"));
                }
            }
        }

        return true;
    }

    private void openGui(Player player) {
        plugin.getGuiListener().getManager().open(player, 0);
    }

    private void handleAdd(CommandSender sender, String[] args) {
        if (!sender.hasPermission("azybountygui.admin")) {
            sender.sendMessage(plugin.msg("no_permission"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(plugin.msg("usage_add"));
            return;
        }

        String targetName = args[1];
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);

        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            sender.sendMessage(plugin.msg("invalid_amount"));
            return;
        }

        if (amount <= 0) {
            sender.sendMessage(plugin.msg("invalid_amount"));
            return;
        }

        boolean ok = plugin.getRepository().addBounty(target.getName() != null ? target.getName() : targetName, amount);
        if (ok) {
            String formatted = amount == Math.floor(amount) ? String.format("%,.0f", amount) : String.format("%,.2f", amount);
            sender.sendMessage(plugin.msg("bounty_added")
                    .replace("{player}", targetName)
                    .replace("{amount}", formatted));
        } else {
            sender.sendMessage(plugin.msg("db_error"));
        }
    }

    private void handleRemove(CommandSender sender, String[] args) {
        if (!sender.hasPermission("azybountygui.admin")) {
            sender.sendMessage(plugin.msg("no_permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(plugin.msg("usage_remove"));
            return;
        }

        String targetName = args[1];
        boolean removed = plugin.getRepository().removeBounty(targetName);
        if (removed) {
            sender.sendMessage(plugin.msg("bounty_removed").replace("{player}", targetName));
        } else {
            sender.sendMessage(plugin.msg("bounty_not_found").replace("{player}", targetName));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.add("add");
            out.add("remove");
            if (sender.hasPermission("azybountygui.admin")) out.add("reload");
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("remove"))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                out.add(p.getName());
            }
        }
        return out;
    }
}
