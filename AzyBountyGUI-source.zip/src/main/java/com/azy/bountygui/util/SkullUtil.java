package com.azy.bountygui.util;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

/**
 * Offline oyuncular için de doğru skin kafası gösterir.
 * Bukkit'in OfflinePlayer#getPlayerProfile() metodu, oyuncu online olmasa
 * bile Mojang / yerel profil önbelleğinden skin verisini çeker ve Paper
 * bunu otomatik olarak asenkron şekilde çözümler.
 */
public final class SkullUtil {

    private SkullUtil() {
    }

    public static ItemStack createPlayerHead(String playerName) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        if (meta == null) {
            return head;
        }

        OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(playerName);
        meta.setOwningPlayer(offlinePlayer);

        head.setItemMeta(meta);
        return head;
    }
}
