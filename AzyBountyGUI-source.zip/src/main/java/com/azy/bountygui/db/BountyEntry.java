package com.azy.bountygui.db;

public class BountyEntry {

    private final String playerName;
    private final double amount;

    public BountyEntry(String playerName, double amount) {
        this.playerName = playerName;
        this.amount = amount;
    }

    public String getPlayerName() {
        return playerName;
    }

    public double getAmount() {
        return amount;
    }
}
