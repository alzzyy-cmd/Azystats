package com.azy.bountygui.db;

import com.azy.bountygui.AzyBountyGUI;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * DonutDatabase eklentisinin storage.db (SQLite) dosyasındaki "bounties"
 * tablosunu doğrudan okur/yazar. Böylece DonutBounty veya DonutDatabase'e
 * API üzerinden bağımlı olmadan, aynı veriye senkron şekilde erişilir.
 *
 * Her işlemde kısa ömürlü bir JDBC bağlantısı açılıp kapatılır; SQLite
 * dosya tabanlı olduğundan bu, eşzamanlı erişimde en güvenli yöntemdir.
 */
public class BountyRepository {

    private final AzyBountyGUI plugin;
    private final String jdbcUrl;
    private final String table;
    private final String playerColumn;
    private final String amountColumn;

    public BountyRepository(AzyBountyGUI plugin) throws Exception {
        this.plugin = plugin;

        String path = plugin.getConfig().getString("database.path", "plugins/DonutDatabase/storage.db");

        // path zaten "plugins/..." ile başladığı için server kök dizinine göre çözümlenmeli.
        // getDataFolder() = plugins/AzyBountyGUI -> parent = plugins -> parent = server kökü
        File dbFile;
        if (!path.startsWith("plugins")) {
            dbFile = new File(path);
        } else {
            dbFile = new File(plugin.getDataFolder().getParentFile().getParentFile(), path);
        }

        if (!dbFile.exists()) {
            throw new IllegalStateException("storage.db bulunamadı: " + dbFile.getAbsolutePath()
                    + " (config.yml -> database.path ayarını kontrol et)");
        }

        this.jdbcUrl = "jdbc:sqlite:" + dbFile.getAbsolutePath();
        this.table = plugin.getConfig().getString("database.table", "bounties");
        this.playerColumn = plugin.getConfig().getString("database.player_column", "player_name");
        this.amountColumn = plugin.getConfig().getString("database.amount_column", "amount");

        Class.forName("org.sqlite.JDBC");

        // Bağlantı testi
        try (Connection con = getConnection()) {
            plugin.getLogger().info("DonutDatabase storage.db bağlantısı başarılı: " + dbFile.getAbsolutePath());
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl);
    }

    /**
     * Tüm bounty kayıtlarını, miktara göre büyükten küçüğe sıralı döner.
     */
    public List<BountyEntry> getAllSortedDesc() {
        List<BountyEntry> list = new ArrayList<>();
        String sql = "SELECT " + playerColumn + ", " + amountColumn + " FROM " + table
                + " ORDER BY " + amountColumn + " DESC";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String name = rs.getString(1);
                double amount = rs.getDouble(2);
                list.add(new BountyEntry(name, amount));
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Bounty listesi okunurken hata oluştu.", e);
        }
        return list;
    }

    /**
     * Belirli bir oyuncunun aktif bounty'sini isim ile arar (case-insensitive).
     */
    public BountyEntry findByName(String playerName) {
        String sql = "SELECT " + playerColumn + ", " + amountColumn + " FROM " + table
                + " WHERE LOWER(" + playerColumn + ") = LOWER(?) LIMIT 1";

        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, playerName);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new BountyEntry(rs.getString(1), rs.getDouble(2));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Bounty aranırken hata oluştu.", e);
        }
        return null;
    }

    /**
     * Bounty ekler veya varsa üzerine ekler (upsert mantığı: eğer kayıt varsa
     * miktarı ARTIRIR, DonutBounty'nin normal davranışına benzer şekilde).
     */
    public boolean addBounty(String playerName, double amount) {
        BountyEntry existing = findByName(playerName);
        try (Connection con = getConnection()) {
            if (existing != null) {
                String sql = "UPDATE " + table + " SET " + amountColumn + " = " + amountColumn
                        + " + ? WHERE LOWER(" + playerColumn + ") = LOWER(?)";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setDouble(1, amount);
                    ps.setString(2, playerName);
                    ps.executeUpdate();
                }
            } else {
                String sql = "INSERT INTO " + table + " (" + playerColumn + ", " + amountColumn + ") VALUES (?, ?)";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, playerName);
                    ps.setDouble(2, amount);
                    ps.executeUpdate();
                }
            }
            return true;
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Bounty eklenirken hata oluştu.", e);
            return false;
        }
    }

    /**
     * Bir oyuncunun bounty kaydını tamamen siler.
     */
    public boolean removeBounty(String playerName) {
        String sql = "DELETE FROM " + table + " WHERE LOWER(" + playerColumn + ") = LOWER(?)";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, playerName);
            int updated = ps.executeUpdate();
            return updated > 0;
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Bounty silinirken hata oluştu.", e);
            return false;
        }
    }

    public void close() {
        // Her işlemde bağlantı zaten kapatılıyor; burada ek bir kaynak yok.
    }
}
