package com.azy.azyistatik;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/**
 * Stats GUI sadece bilgi amaçlı olduğu için içindeki hiçbir item
 * alınamaz, taşınamaz veya bırakılamaz.
 */
public class StatsGuiListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof StatsInventoryHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof StatsInventoryHolder) {
            event.setCancelled(true);
        }
    }
}
