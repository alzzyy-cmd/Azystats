package com.azy.azyistatik;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

/**
 * PlaceholderAPI kurulu değilse plugin'in patlamaması için güvenli bir köprü.
 * PlaceholderAPI plugin.yml'de softdepend olarak tanımlı olduğu için,
 * PlaceholderAPI kuruluysa class'larına güvenle erişilebilir; kurulu değilse
 * hiçbir çağrı yapılmadan fallback metin döner.
 */
public class PlaceholderHook {

    private static Boolean papiPresent = null;

    public static boolean isPresent() {
        if (papiPresent == null) {
            papiPresent = Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
        }
        return papiPresent;
    }

    /**
     * Verilen placeholder string'ini (örn. "%vault_eco_balance%") çözüp döner.
     * PlaceholderAPI yoksa veya bir hata olursa fallback metni döner.
     */
    public static String resolve(OfflinePlayer player, String placeholder, String fallback) {
        if (!isPresent() || placeholder == null || placeholder.isEmpty()) {
            return fallback;
        }
        try {
            String result = me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(player, placeholder);
            if (result == null || result.isEmpty() || result.equals(placeholder)) {
                return fallback;
            }
            return result;
        } catch (Throwable t) {
            return fallback;
        }
    }
}
