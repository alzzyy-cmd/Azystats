package com.azy.azyistatik;

import org.bukkit.plugin.java.JavaPlugin;

public class AzyIstatik extends JavaPlugin {

    private static AzyIstatik instance;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        StatsCommand statsCommand = new StatsCommand(this);
        getCommand("azyistatik").setExecutor(statsCommand);
        getCommand("azyistatik").setTabCompleter(statsCommand);

        getServer().getPluginManager().registerEvents(new StatsGuiListener(), this);

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") == null) {
            getLogger().warning("PlaceholderAPI bulunamadı! Bakiye/Shards/Playtime gibi " +
                    "değerler config'te ayarlanan fallback yazıyla gösterilecek.");
        }

        getLogger().info("AzyIstatik aktif edildi. Komut: /azyistatik (/stats, /istatistik, /istatik)");
    }

    @Override
    public void onDisable() {
        getLogger().info("AzyIstatik devre dışı bırakıldı.");
    }

    public void reload() {
        reloadConfig();
    }

    public static AzyIstatik getInstance() {
        return instance;
    }
}
