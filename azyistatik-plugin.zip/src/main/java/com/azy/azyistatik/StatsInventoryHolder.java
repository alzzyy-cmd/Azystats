package com.azy.azyistatik;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Stats GUI'sini diğer inventory'lerden ayırt edebilmek için kullanılan
 * işaretleyici holder. Böylece tıklama event'inde sadece bu GUI'de
 * item alınmasını engelleyebiliyoruz, oyuncunun kendi envanterine dokunmuyoruz.
 */
public class StatsInventoryHolder implements InventoryHolder {

    private Inventory inventory;

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
