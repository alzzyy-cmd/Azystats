package com.azy.azyistatik;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * "/azyistatik <oyuncu>" ekranında açılan GUI'yi tamamen config.yml
 * üzerinden oluşturur. Hangi item hangi slotta, ne materyalde, ne
 * yazdığı ve verinin nereden geldiği (PlaceholderAPI ya da Minecraft
 * istatistiği) config.yml -> stats.items altından okunur.
 *
 * Kenarlar bilinçli olarak boş (air) bırakılır, herhangi bir cam
 * panel çerçeve kullanılmaz.
 */
public class StatsGUI {

    private final AzyIstatik plugin;

    public StatsGUI(AzyIstatik plugin) {
        this.plugin = plugin;
    }

    public Inventory build(OfflinePlayer target) {
        int size = plugin.getConfig().getInt("stats.size", 27);
        if (size <= 0 || size % 9 != 0) {
            size = 27;
        }

        String titleTemplate = plugin.getConfig().getString("stats.gui-title", "&a&l%player% STATS");
        String playerName = target.getName() == null ? "Bilinmeyen" : target.getName();
        String title = ChatColor.translateAlternateColorCodes('&', titleTemplate.replace("%player%", playerName));

        StatsInventoryHolder holder = new StatsInventoryHolder();
        Inventory inv = Bukkit.createInventory(holder, size, title);
        holder.setInventory(inv);

        String fallback = ChatColor.translateAlternateColorCodes('&',
                plugin.getConfig().getString("stats.placeholder-not-found-text", "&cPlaceholderAPI yok"));

        List<Map<?, ?>> items = plugin.getConfig().getMapList("stats.items");
        for (Map<?, ?> raw : items) {
            try {
                int slot = toInt(raw.get("slot"), -1);
                if (slot < 0 || slot >= size) continue;

                Material material = Material.matchMaterial(String.valueOf(raw.get("material")));
                if (material == null) continue;

                String name = raw.get("name") == null ? "" : String.valueOf(raw.get("name"));
                String source = raw.get("source") == null ? "" : String.valueOf(raw.get("source"));
                String placeholder = raw.get("placeholder") == null ? null : String.valueOf(raw.get("placeholder"));

                String value = resolveValue(target, source, placeholder, fallback);

                List<String> loreLines = new ArrayList<>();
                Object loreObj = raw.get("lore");
                if (loreObj instanceof List) {
                    for (Object line : (List<?>) loreObj) {
                        loreLines.add(String.valueOf(line).replace("%value%", value));
                    }
                } else {
                    loreLines.add("&f" + value);
                }

                inv.setItem(slot, createItem(material, name, loreLines));
            } catch (Exception ignored) {
                // Hatalı bir config satırı tüm GUI'yi bozmasın diye atlanır
            }
        }

        // Geliştirici bilgisi (config dışında sabit)
        int creditSlot = size - 5;
        if (creditSlot >= 0 && creditSlot < size && inv.getItem(creditSlot) == null) {
            List<String> creditLore = new ArrayList<>();
            creditLore.add("&7Bu istatistik ekranı");
            creditLore.add("&b&lazy &7(&balzzyy&7) &7tarafından");
            creditLore.add("&7geliştirilmiştir.");
            inv.setItem(creditSlot, createItem(Material.NETHER_STAR, "&b&lAzyIstatik", creditLore));
        }

        return inv;
    }

    private String resolveValue(OfflinePlayer target, String source, String placeholder, String fallback) {
        switch (source) {
            case "papi":
                return PlaceholderHook.resolve(target, placeholder, fallback);
            case "kills":
                return StatsCollector.format(StatsCollector.getTotalKills(target));
            case "deaths":
                return StatsCollector.format(StatsCollector.getDeaths(target));
            case "mobkills":
                return StatsCollector.format(StatsCollector.getMobKills(target));
            case "mined":
                return StatsCollector.format(StatsCollector.getBlocksMined(target));
            case "placed":
                return StatsCollector.format(StatsCollector.getBlocksPlaced(target));
            default:
                return fallback;
        }
    }

    private int toInt(Object value, int def) {
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        if (value == null) return def;
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private ItemStack createItem(Material material, String name, List<String> loreRaw) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            List<String> lore = new ArrayList<>();
            for (String line : loreRaw) {
                lore.add(ChatColor.translateAlternateColorCodes('&', line));
            }
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }
}
