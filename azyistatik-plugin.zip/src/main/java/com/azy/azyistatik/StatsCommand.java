package com.azy.azyistatik;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /azyistatik [oyuncu] ve alias'ları (/stats, /istatistik, /istatik).
 * Online/offline farketmeksizin herhangi bir oyuncunun istatistiğine bakılabilir.
 *
 * NOT: Oyuncu araması tamamen yerel/offline yapılır (Bukkit.getOfflinePlayers()
 * ile sunucunun kendi kayıtlı oyuncu listesi taranır). Bukkit.getOfflinePlayer(String)
 * KASITLI OLARAK kullanılmaz çünkü o metot bazı sunucu kurulumlarında ismi çözmek
 * için internete (Mojang API) çıkabilir; bu da offline oyuncu aramasını
 * güvenilmez/yavaş hale getiriyordu.
 */
public class StatsCommand implements CommandExecutor, TabCompleter {

    private final AzyIstatik plugin;
    private final StatsGUI gui;

    public StatsCommand(AzyIstatik plugin) {
        this.plugin = plugin;
        this.gui = new StatsGUI(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!plugin.getConfig().getBoolean("stats.enabled", true)) {
            sender.sendMessage(ChatColor.RED + "İstatistik sistemi şu anda kapalı.");
            return true;
        }

        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Bu komut sadece oyuncular tarafından kullanılabilir.");
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("azyistatik.kullan")) {
            player.sendMessage(ChatColor.RED + "Bu komutu kullanma yetkin yok.");
            return true;
        }

        OfflinePlayer target;
        if (args.length >= 1) {
            target = findOfflinePlayer(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "Bu isimde bir oyuncu bulunamadı: " + args[0]);
                return true;
            }
        } else {
            target = player;
        }

        player.openInventory(gui.build(target));
        return true;
    }

    /**
     * Hem online hem daha önce sunucuya katılmış offline oyuncuları,
     * hiçbir internet/Mojang API çağrısı yapmadan, tamamen yerel olarak arar.
     */
    private OfflinePlayer findOfflinePlayer(String name) {
        // Once online oyuncularda hizlica ara (buyuk/kucuk harf farketmez)
        Player online = Bukkit.getPlayer(name);
        if (online != null) {
            return online;
        }

        // Sunucunun kendi kayitli (daha once en az bir kez katilmis) oyuncu listesinde ara
        for (OfflinePlayer offline : Bukkit.getOfflinePlayers()) {
            if (offline.getName() != null && offline.getName().equalsIgnoreCase(name)) {
                return offline;
            }
        }

        return null;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String partial = args[0].toLowerCase();
            List<String> names = new ArrayList<>();
            for (Player online : Bukkit.getOnlinePlayers()) {
                names.add(online.getName());
            }
            return names.stream()
                    .filter(name -> name.toLowerCase().startsWith(partial))
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}
