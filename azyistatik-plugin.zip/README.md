# AzyIstatik

Oyuncu istatistik (STATS) GUI plugin'i (Paper 1.21.8). azy (alzzyy) tarafından yazıldı.

## Komut

`/azyistatik [oyuncu]` — alias'ları: `/stats`, `/istatistik`, `/istatik`

Oyuncu adı verilmezse kendi istatistiğini, verilirse (online/offline fark etmeden)
o oyuncunun istatistiğini gösterir.

## GUI İçeriği

- Zümrüt → Bakiye
- Ametist → Shards değeri
- Elmas kılıç → Toplam öldürme
- Kırık taş → Kırılan blok
- Saat → Playtime
- Taş → Koyulan blok
- Zombi kafası → Öldürülen mob sayısı
- Altın parça → Kazanılan para
- Demir parça → Kaybedilen para

Tamamen bilgi amaçlıdır, hiçbir item alınamaz.

## Config (`config.yml`)

Bakiye/Shards/Kazanılan-Kaybedilen Para/Playtime değerleri **PlaceholderAPI** üzerinden
okunur. Sunucunda PlaceholderAPI kurulu olmalı, kullandığın ekonomi/playtime pluginine
göre `config.yml`'deki placeholder isimlerini değiştirmen gerekebilir.

## Build

```bash
mvn clean package
```

Çıktı: `target/AzyIstatik-1.0.0.jar`
